package main

import (
    "fmt"
    "log"
    "net/http"
    "github.com/gorilla/websocket"
)

const html = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hive Public Node</title>
    <style>
        body { font-family: sans-serif; background: #0e0e0e; color: #eee; text-align: center; padding-top: 50px; }
        h1 { font-size: 3em; color: #00ffd0; }
        p { font-size: 1.2em; }
    </style>
</head>
<body>
    <h1>Welcome to Hive</h1>
    <p>This is a public Hive node visible to other users.</p>
</body>
</html>
`

func main() {
    go func() {
        http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
            w.Header().Set("Content-Type", "text/html")
            fmt.Fprint(w, html)
        })
        log.Println("✅ Hosting on 0.0.0.0:8080")
        log.Fatal(http.ListenAndServe(":8080", nil))
    }()

    // IP-адрес сервера, укажи свой вручную ниже:
    ip = "10.0.0.15:8080"           // внутри LAN
    ip := "77.239.114.165:8080"     // если порт открыт снаружи

    url := "ws://77.239.114.165:443/join"
    conn, _, err := websocket.DefaultDialer.Dial(url, nil)
    if err != nil {
        log.Fatal("❌ Failed to connect to lobby:", err)
    }
    defer conn.Close()

    publishMsg := "publish:hive.hive:" + ip
    log.Println("➡️ Sending publish message:", publishMsg)
    err = conn.WriteMessage(websocket.TextMessage, []byte(publishMsg))
    if err != nil {
        log.Fatal("❌ Failed to publish domain:", err)
    }

    log.Println("✅ Published domain hive.hive ->", ip)

    for {
        _, msg, err := conn.ReadMessage()
        if err != nil {
            log.Println("🔌 Disconnected:", err)
            break
        }
        log.Println("📩 Received:", string(msg))
    }
}
